<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title><?= $title ?? 'Jadwal Temu' ?></title>
    <!-- Contoh pakai Bootstrap CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Contoh pakai Tailwind CDN, kalau mau ganti -->
    <!-- <script src="https://cdn.tailwindcss.com"></script> -->

    <!-- Bisa juga taruh CSS custom -->
    <link rel="stylesheet" href="/style.css">
</head>
<body>
