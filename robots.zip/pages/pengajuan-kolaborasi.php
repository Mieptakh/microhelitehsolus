<?php
require_once __DIR__ . '/../webmaster/includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_instansi = $_POST['nama_instansi'] ?? '';
    $kontak = $_POST['kontak'] ?? '';
    $barter_value = $_POST['barter_value'] ?? '';

    // Proses upload file (hanya 1 file untuk contoh ini)
    $lampiran = null;
    if (isset($_FILES['lampiran']) && $_FILES['lampiran']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = __DIR__ . '/uploads/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        $filename = basename($_FILES['lampiran']['name']);
        $targetFile = $uploadDir . time() . '_' . $filename;
        if (move_uploaded_file($_FILES['lampiran']['tmp_name'], $targetFile)) {
            $lampiran = basename($targetFile);
        } else {
            echo "Gagal mengupload file.";
        }
    }

    // Simpan ke database
    if ($nama_instansi && $kontak && $barter_value) {
        $stmt = $pdo->prepare("INSERT INTO pengajuan_kolaborasi (nama_instansi, kontak, barter_value, lampiran) VALUES (?, ?, ?, ?)");
        $stmt->execute([$nama_instansi, $kontak, $barter_value, $lampiran]);
        echo "Pengajuan kolaborasi berhasil dikirim.";
    } else {
        echo "Lengkapi semua data.";
    }
}
?>

<h2>Form Pengajuan Kolaborasi</h2>
<form method="post" enctype="multipart/form-data">
    <label>Nama/Instansi yang diwakili:</label><br>
    <input type="text" name="nama_instansi" required><br><br>

    <label>Kontak yang dapat dihubungi:</label><br>
    <input type="text" name="kontak" required><br><br>

    <label>Barter Value (jelaskan keuntungan/barter yang diinginkan):</label><br>
    <textarea name="barter_value" rows="4" required></textarea><br><br>

    <label>Upload Lampiran (file pendukung seperti bukti followers, sosial media, dll):</label><br>
    <input type="file" name="lampiran" accept=".jpg,.jpeg,.png,.pdf,.doc,.docx"><br><br>

    <button type="submit">Kirim Pengajuan</button>
</form>
