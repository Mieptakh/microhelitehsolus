<?php include 'includes/head.php'; ?>
<?php include 'includes/header.php'; ?>
<?php
require_once __DIR__ . '/../webmaster/includes/db.php'; // sesuaikan path jika kamu taruh di subfolder

// Ambil semua data paket
try {
    $stmt = $pdo->query("SELECT * FROM packages ORDER BY price ASC");
    $packages = $stmt->fetchAll();
} catch (PDOException $e) {
    die("Gagal memuat paket: " . htmlspecialchars($e->getMessage()));
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Semua Paket Website - MHTeams</title>
    <link rel="stylesheet" href="styles.css"> <!-- sesuaikan jika pakai CSS eksternal -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"> <!-- pastikan FA tersedia -->
</head>
<body>

<section class="ratecard-section" data-aos="fade-up">
    <div class="container">
        <h2><i class="fa-solid fa-boxes-stacked"></i> Semua Paket Website</h2>
        <p class="section-subtitle">Temukan paket yang sesuai dengan kebutuhan dan anggaran Anda.</p>

        <?php if (count($packages) > 0): ?>
        <div class="ratecard-grid">
            <?php foreach ($packages as $package): ?>
            <div class="ratecard-card">
                <div class="ratecard-header">
                    <h3><?php echo htmlspecialchars($package['name']); ?></h3>
                    <div class="price">Rp <?php echo number_format($package['price'], 0, ',', '.'); ?></div>
                </div>
                <ul class="features">
                    <?php 
                    $features = explode(',', $package['features']);
                    foreach ($features as $feature): 
                    ?>
                    <li><i class="fa-solid fa-check"></i> <?php echo htmlspecialchars(trim($feature)); ?></li>
                    <?php endforeach; ?>
                </ul>
                <a href="detail-paket.php?slug=<?php echo urlencode($package['slug']); ?>" class="btn-ratecard">
                    Lihat Detail <i class="fa-solid fa-arrow-right"></i>
                </a>
            </div>
            <?php endforeach; ?>
        </div>
        <?php else: ?>
            <div class="no-data">Belum ada paket yang tersedia saat ini.</div>
        <?php endif; ?>
    </div>
</section>

</body>
<?php include 'includes/footer.php'; ?>
</html>
