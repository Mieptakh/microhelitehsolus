<?php 
include 'includes/head.php';
include 'includes/header.php';

require_once __DIR__ . '/../webmaster/includes/db.php'; // sesuaikan path sesuai struktur kamu

if (!isset($_GET['slug'])) {
    die("Slug paket tidak ditemukan.");
}

$slug = $_GET['slug'];

try {
    $stmt = $pdo->prepare("SELECT * FROM packages WHERE slug = ?");
    $stmt->execute([$slug]);
    $package = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$package) {
        die("Paket tidak tersedia.");
    }
} catch (PDOException $e) {
    die("Kesalahan database: " . htmlspecialchars($e->getMessage()));
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <title><?php echo htmlspecialchars($package['name']); ?> - Detail Paket</title>
    <link rel="stylesheet" href="styles.css" />
    <!-- Link fontawesome jika belum ada -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <style>
        /* Tambahan CSS sederhana */
        .package-detail { padding: 2rem; max-width: 900px; margin: auto; }
        .price { font-size: 1.3rem; margin-bottom: 1rem; font-weight: bold; }
        ul.features { list-style: none; padding-left: 0; }
        ul.features li { margin-bottom: 0.5rem; }
        .btn-contact, .btn-preview {
            display: inline-block;
            padding: 10px 18px;
            margin: 10px 10px 20px 0;
            text-decoration: none;
            border-radius: 6px;
            font-weight: 600;
            color: white;
            background-color: #007bff;
            transition: background-color 0.3s ease;
        }
        .btn-contact:hover, .btn-preview:hover { background-color: #0056b3; }
        .screenshot-gallery {
            margin-top: 2rem;
        }
        .gallery-grid {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
        }
        .gallery-grid img {
            max-width: 280px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.15);
        }
    </style>
</head>
<body>
    <section class="package-detail">
        <div class="container">
            <h1><?php echo htmlspecialchars($package['name']); ?></h1>
            <p class="price">Harga: Rp <?php echo number_format($package['price'], 0, ',', '.'); ?></p>

            <h3>Fitur:</h3>
            <ul class="features">
                <?php
                $features = explode(',', $package['features']);
                foreach ($features as $feature): ?>
                    <li><i class="fa-solid fa-check"></i> <?php echo htmlspecialchars(trim($feature)); ?></li>
                <?php endforeach; ?>
            </ul>

            <?php if (!empty($package['preview_url'])): ?>
                <a href="<?php echo htmlspecialchars($package['preview_url']); ?>" class="btn-preview" target="_blank" rel="noopener noreferrer">
                    <i class="fa-solid fa-eye"></i> Live Preview
                </a>
            <?php endif; ?>

            <?php if (!empty($package['screenshots'])): ?>
                <div class="screenshot-gallery">
                    <h3>Contoh Tampilan:</h3>
                    <div class="gallery-grid">
                        <?php
                        $screenshots = explode(',', $package['screenshots']);
                        foreach ($screenshots as $img):
                            $img = trim($img);
                        ?>
                            <img src="/assets/screenshots/<?php echo htmlspecialchars($img); ?>" alt="Screenshot <?php echo htmlspecialchars($package['name']); ?>" />
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>

            <a href="contact.php?package=<?php echo urlencode($package['name']); ?>" class="btn-contact">
                Hubungi Kami <i class="fa-solid fa-envelope"></i>
            </a>
        </div>
    </section>

<?php include 'includes/footer.php'; ?>
</body>
</html>
