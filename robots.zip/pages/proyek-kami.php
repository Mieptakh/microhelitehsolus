<?php 
include 'includes/head.php'; 
include 'includes/header.php'; 

require_once __DIR__ . '/../webmaster/includes/db.php'; // sesuaikan path-nya

?>

<section id="all-projects" class="projects-section" data-aos="fade-up">
    <div class="container">
        <h2><i class="fa-solid fa-laptop-code"></i> Semua Proyek Kami</h2>
        <p class="section-subtitle">Inilah seluruh proyek inovatif yang telah kami kembangkan.</p>

        <div class="projects-grid">
            <?php
            try {
                $query = "SELECT * FROM projects ORDER BY date_added DESC";
                $stmt = $pdo->query($query);

                if ($stmt->rowCount() === 0) {
                    echo "<p>Tidak ada proyek yang tersedia saat ini.</p>";
                } else {
                    while ($project = $stmt->fetch(PDO::FETCH_ASSOC)):
                        $projectSlug = htmlspecialchars($project['slug']);
                        $projectName = htmlspecialchars($project['name']);
                        $projectDesc = htmlspecialchars($project['description']);
                        $projectIcon = htmlspecialchars($project['icon']);
                        $projectImage = htmlspecialchars($project['image']);
                        $projectUrl = !empty($project['url']) ? htmlspecialchars($project['url']) : '';
            ?>
            <div class="project-card" data-aos="zoom-in">
                <img src="projects/<?php echo $projectImage; ?>" alt="<?php echo $projectName; ?>" loading="lazy" />
                <div class="project-info">
                    <h3><i class="fa-solid fa-<?php echo $projectIcon; ?>"></i> <?php echo $projectName; ?></h3>
                    <p><?php echo $projectDesc; ?></p>
                    <div class="project-actions">
                        <a href="detail-proyek.php?slug=<?php echo urlencode($projectSlug); ?>" class="btn-project-detail" aria-label="Detail proyek <?php echo $projectName; ?>">
                            <i class="fa-solid fa-info-circle"></i> Detail
                        </a>
                        <?php if ($projectUrl): ?>
                        <a href="<?php echo $projectUrl; ?>" target="_blank" rel="noopener noreferrer" class="btn-project" aria-label="Kunjungi proyek <?php echo $projectName; ?>">
                            <i class="fa-solid fa-arrow-right"></i> Kunjungi
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php 
                    endwhile;
                }
            } catch (PDOException $e) {
                echo "<div class='error'>Gagal memuat data proyek: " . htmlspecialchars($e->getMessage()) . "</div>";
            }
            ?>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
