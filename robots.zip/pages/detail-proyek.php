<?php 
include 'includes/head.php';
include 'includes/header.php';

require_once __DIR__ . '/../webmaster/includes/db.php'; // Sesuaikan path

// Validasi parameter slug
if (!isset($_GET['slug']) || empty($_GET['slug'])) {
    die("Slug proyek tidak valid.");
}

$slug = $_GET['slug'];

try {
    $stmt = $pdo->prepare("SELECT * FROM projects WHERE slug = ?");
    $stmt->execute([$slug]);
    $project = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$project) {
        die("Proyek tidak ditemukan.");
    }
} catch (PDOException $e) {
    die("Kesalahan database: " . htmlspecialchars($e->getMessage()));
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <title><?php echo htmlspecialchars($project['name']); ?> - Detail Proyek</title>
    <link rel="stylesheet" href="styles.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <style>
        .project-detail { max-width: 900px; margin: 2rem auto; padding: 1rem; }
        .project-detail img { max-width: 100%; border-radius: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
        h1 { margin-bottom: 0.5rem; }
        .project-info { margin-top: 1rem; }
        .project-description { margin-top: 1rem; line-height: 1.5; font-size: 1.1rem; }
        .btn-visit, .btn-back {
            display: inline-block;
            margin-top: 1.5rem;
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            transition: background-color 0.3s ease;
        }
        .btn-visit:hover, .btn-back:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <section class="project-detail">
        <h1><i class="fa-solid fa-<?php echo htmlspecialchars($project['icon']); ?>"></i> <?php echo htmlspecialchars($project['name']); ?></h1>
        <img src="projects/<?php echo htmlspecialchars($project['image']); ?>" alt="<?php echo htmlspecialchars($project['name']); ?>" />
        
        <div class="project-info">
            <p class="project-description"><?php echo nl2br(htmlspecialchars($project['description'])); ?></p>

            <?php if (!empty($project['url'])): ?>
                <a href="<?php echo htmlspecialchars($project['url']); ?>" target="_blank" rel="noopener noreferrer" class="btn-visit">
                    <i class="fa-solid fa-arrow-up-right-from-square"></i> Kunjungi Proyek
                </a>
            <?php endif; ?>

            <a href="/proyek-kami" class="btn-back">
                <i class="fa-solid fa-chevron-left"></i> Kembali ke Daftar Proyek
            </a>
        </div>
    </section>

<?php include 'includes/footer.php'; ?>
</body>
</html>
