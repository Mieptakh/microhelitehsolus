<?php
require_once __DIR__ . '/includes/auth.php';

if (!isLoggedIn()) {
    header('Location: /webmaster/index.php');
    exit;
}

$title = "Dashboard Webmaster";
include __DIR__ . '/include/head.php';
?>

<div class="container my-4">
    <h1>Selamat datang, Admin!</h1>
    <ul class="list-group">
        <li class="list-group-item"><a href="/webmaster/edit-paket">Edit Paket</a></li>
        <li class="list-group-item"><a href="/webmaster/edit-proyek">Edit Proyek</a></li>
        <li class="list-group-item"><a href="/webmaster/edit-testimoni">Edit Testimoni</a></li>
        <li class="list-group-item"><a href="/webmaster/tampilkan-kontak">Lihat Kontak</a></li>
        <li class="list-group-item"><a href="/webmaster/tampilkan-jadwal-temu">Lihat Jadwal Temu</a></li>
        <li class="list-group-item"><a href="/webmaster/tampilkan-pengajuan-kolaborasi">Lihat Kolaborasi</a></li>
    </ul>

    <form method="post" action="/webmaster/logout.php" class="mt-3">
        <button type="submit" class="btn btn-danger">Logout</button>
    </form>
</div>

<?php include __DIR__ . '/include/footer.php'; ?>
